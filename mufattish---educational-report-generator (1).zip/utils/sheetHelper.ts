
import { Teacher, ReportData, ObservationItem, LegacyReportOptions } from '../types';
import { DEFAULT_OBSERVATION_TEMPLATE, INITIAL_REPORT_STATE } from '../constants';

const generateId = () => Math.random().toString(36).substr(2, 9);

/**
 * Helper to convert various date formats to standard YYYY-MM-DD for HTML5 inputs
 */
const normalizeDate = (val: any): string => {
    if (!val) return '';
    const str = String(val).trim();
    
    // 1. Handle Excel Serial Numbers (e.g. 44562) which Google Sheets sometimes returns for dates
    if (/^\d+$/.test(str) && Number(str) > 20000) { 
        // 25569 is the offset between Excel (1900) and JS (1970) epochs
        const date = new Date(Math.round((Number(str) - 25569) * 86400 * 1000));
        if (!isNaN(date.getTime())) {
            return date.toISOString().split('T')[0];
        }
    }

    // 2. Handle DD/MM/YYYY (Common in Arab/French regions)
    if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(str)) {
        const [d, m, y] = str.split('/');
        return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
    }
    
    // 3. Handle YYYY/MM/DD
    if (/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(str)) {
         return str.replace(/\//g, '-');
    }

    // 4. Return as is (Assumes YYYY-MM-DD)
    return str;
};

/**
 * Helper to map Arabic or various status text to internal codes
 */
const normalizeStatus = (val: any): 'titulaire' | 'contractuel' | 'stagiere' => {
    const s = String(val).trim().toLowerCase();
    if (s.includes('متعاقد') || s.includes('contract')) return 'contractuel';
    if (s.includes('متربص') || s.includes('stag')) return 'stagiere';
    // Default to titulaire (مرسم) if unclear or matches 'titulaire'/'مرسم'
    return 'titulaire';
};

/**
 * Generates a 2D array (Rows x Columns) representing the database.
 * This format is directly accepted by the Google Sheets API.
 */
export const generateDatabaseRows = (
    teachers: Teacher[], 
    currentReport?: ReportData,
    reportsMap?: Record<string, ReportData>
): (string | number)[][] => {
    // 1. Build Headers
    // Existing Headers (Indices 0-13) -> FIXED DO NOT CHANGE
    const basicHeaders = [
        'ID', 'الاسم_واللقب', 'تاريخ_الميلاد', 'مكان_الميلاد', 'الشهادة', 'تاريخ_الشهادة',
        'تاريخ_التوظيف', 'الرتبة', 'تاريخ_الرتبة', 'الدرجة', 'تاريخ_الدرجة',
        'تاريخ_آخر_تفتيش', 'النقطة_السابقة', 'الوضعية'
    ];

    // Existing Report Headers (Indices 14-28) -> FIXED DO NOT CHANGE
    const reportHeaders = [
        'الولاية', 'المقاطعة', 'المدرسة', 
        'تاريخ_الزيارة', 'المادة', 'الموضوع', 'المدة', 'المستوى', 'الفوج', 
        'عدد_التلاميذ', 'الغائبون', 'السبورة', 'العلامة_النهائية', 'العلامة_بالحروف', 'توجيهات_التقييم'
    ];

    // NEW: Legacy & Meta Headers (Indices 29-64)
    // These are inserted IN BETWEEN the report info and the observations grid.
    const legacyHeaders = [
        'نوع_التقرير', // Index 29: Report Model (modern/legacy)
        'اسم_المفتش',  // Index 30
        'الحالة_العائلية', 'معهد_التكوين', 'تاريخ_التخرج_من_المعهد', 'تاريخ_المؤهل_العلمي', // Personal extras
        'السنة_الدراسية', 'الدائرة', 'البلدية', // Admin extras
        'القاعة_استماع', 'الإضاءة', 'التدفئة', 'التهوية', 'النظافة', // Environment
        'إعداد_الدروس', 'قيمة_الإعداد', 'وسائل_أخرى', 'السبورة', 'التوزيع_والمعلقات', // Prep
        'السجلات', 'السجلات_مستعملة', 'السجلات_مراقبة', // Registers
        
        // New Fields matching the document strict structure
        'البرامج_المقررة', 'التدرج', 'الواجبات',

        'تسلسل_الدروس', 'قيمة_المعلومات', 'تحقق_الأهداف', 'مشاركة_التلاميذ', // Execution
        'التطبيقات', 'ملاءمة_التطبيقات', // Apps
        'العناية_بالدفاتر', 'مراقبة_الدفاتر', 'تصحيح_الواجبات', 'قيمة_التصحيح', // Notebooks
        'التقدير_العام_الكلاسيكي' // Index 64
    ];

    // Dynamic Observation Headers (Indices 65+)
    const obsHeaders: string[] = [];
    DEFAULT_OBSERVATION_TEMPLATE.forEach(obs => {
        obsHeaders.push(`معيار_${obs.id}_التقييم`); // Score
        obsHeaders.push(`معيار_${obs.id}_ملاحظات`); // Note
    });

    const allHeaders = [...basicHeaders, ...reportHeaders, ...legacyHeaders, ...obsHeaders];

    // 2. Build Rows
    const rows = teachers.map(t => {
        // Determine which report data to use for this teacher
        let r: ReportData = INITIAL_REPORT_STATE;
        let hasReport = false;

        if (currentReport && currentReport.teacherId === t.id) {
            // Priority: The one currently being edited in the UI
            r = currentReport;
            hasReport = true;
        } else if (reportsMap && reportsMap[t.id]) {
            // Secondary: The one stored in the local Map
            r = reportsMap[t.id];
            hasReport = true;
        }

        // Ensure legacyData object exists even if empty
        const ld = r.legacyData || INITIAL_REPORT_STATE.legacyData!;

        const basicData = [
            t.id, t.fullName, t.birthDate, t.birthPlace, t.degree, t.degreeDate || '',
            t.recruitmentDate, t.rank, t.currentRankDate || '', t.echelon || '', t.echelonDate || '',
            t.lastInspectionDate, t.lastMark, t.status
        ];

        const reportData = [
            hasReport ? r.wilaya : '',
            hasReport ? r.district : '',
            hasReport ? r.school : '',
            hasReport ? r.inspectionDate : '',
            hasReport ? r.subject : '',
            hasReport ? r.topic : '',
            hasReport ? r.duration : '',
            hasReport ? r.level : '',
            hasReport ? r.group : '',
            hasReport ? r.studentCount : '',
            hasReport ? r.absentCount : '',
            hasReport ? r.generalAssessment : '', 
            hasReport ? r.finalMark : '',
            hasReport ? r.markInLetters : '',
            hasReport ? (r.assessmentKeywords || '') : ''
        ];

        const legacyDataCols = [
            hasReport ? (r.reportModel || 'modern') : 'modern',
            hasReport ? (r.inspectorName || '') : '',
            hasReport ? ld.familyStatus : '',
            hasReport ? ld.trainingInstitute : '',
            hasReport ? ld.trainingDate : '',
            hasReport ? ld.graduationDate : '',
            hasReport ? ld.schoolYear : '',
            hasReport ? ld.daira : '',
            hasReport ? ld.municipality : '',
            hasReport ? ld.classroomListening : '',
            hasReport ? ld.lighting : '',
            hasReport ? ld.heating : '',
            hasReport ? ld.ventilation : '',
            hasReport ? ld.cleanliness : '',
            hasReport ? ld.lessonPreparation : '',
            hasReport ? ld.preparationValue : '',
            hasReport ? ld.otherAids : '',
            hasReport ? ld.boardWork : '',
            hasReport ? ld.documentsAndPosters : '',
            hasReport ? ld.registers : '',
            hasReport ? ld.registersUsed : '',
            hasReport ? ld.registersMonitored : '',
            
            // New Fields
            hasReport ? ld.scheduledPrograms : '',
            hasReport ? ld.progression : '',
            hasReport ? ld.duties : '',

            hasReport ? ld.lessonExecution : '',
            hasReport ? ld.informationValue : '',
            hasReport ? ld.objectivesAchieved : '',
            hasReport ? ld.studentParticipation : '',
            hasReport ? ld.applications : '',
            hasReport ? ld.applicationsSuitability : '',
            hasReport ? ld.notebooksCare : '',
            hasReport ? ld.notebooksMonitored : '',
            hasReport ? ld.homeworkCorrection : '',
            hasReport ? ld.homeworkValue : '',
            hasReport ? ld.generalAppreciation : ''
        ];

        const obsData: (string | number)[] = [];
        DEFAULT_OBSERVATION_TEMPLATE.forEach(tmpl => {
            if (hasReport) {
                const found = r.observations.find(o => o.id === tmpl.id);
                const score = (found?.score != null) ? found.score : '';
                const note = found?.improvementNotes || '';
                
                obsData.push(score);
                obsData.push(note);
            } else {
                obsData.push('');
                obsData.push('');
            }
        });

        return [...basicData, ...reportData, ...legacyDataCols, ...obsData];
    });

    return [allHeaders, ...rows];
};

/**
 * Parses the 2D array from Google Sheets back into App Data.
 * Includes logic to detect if the sheet is Old Format (Observation at 29) or New Format (Observation at 62/65).
 */
export const parseDatabaseRows = (values: any[][]): { teachers: Teacher[], reportsMap: Record<string, ReportData> } => {
    if (!values || values.length < 2) return { teachers: [], reportsMap: {} };

    // Row 0 is headers, start from 1
    // Check Header at Index 29 to determine version
    const headerRow = values[0];
    // If header 29 contains "نوع_التقرير" or "Report Model", it's the NEW format.
    // If header 29 contains "معيار" or is empty/different, it might be the OLD format.
    const isNewFormat = headerRow[29] && (String(headerRow[29]).includes('نوع_التقرير') || String(headerRow[29]).includes('Legacy'));
    
    // Attempt to detect if it is the "Latest" format with 65 columns (has scheduledPrograms) or "Previous" 62 columns
    // Index 51 in latest format is 'البرامج_المقررة' or 'scheduledPrograms'
    // Index 51 in previous format was 'تسلسل_الدروس' or 'lessonExecution'
    const isLatestFormat = isNewFormat && (String(headerRow[51]).includes('البرامج') || String(headerRow[51]).includes('scheduled'));

    const teachers: Teacher[] = [];
    const reportsMap: Record<string, ReportData> = {};

    for (let i = 1; i < values.length; i++) {
        const row = values[i];
        if (!row || row.length === 0) continue;

        // Helper to safely get value at index
        const getVal = (idx: number): string => {
            const val = row[idx];
            if (val === undefined || val === null) return '';
            if (typeof val === 'object') return JSON.stringify(val);
            return String(val).trim();
        };

        // Basic Validation
        if (!getVal(1)) continue; // No name

        const id = getVal(0) || generateId();
        
        const teacher: Teacher = {
            id: id,
            fullName: getVal(1),
            birthDate: normalizeDate(getVal(2)),
            birthPlace: getVal(3),
            degree: getVal(4),
            degreeDate: normalizeDate(getVal(5)),
            recruitmentDate: normalizeDate(getVal(6)),
            rank: getVal(7),
            currentRankDate: normalizeDate(getVal(8)),
            echelon: getVal(9),
            echelonDate: normalizeDate(getVal(10)),
            lastInspectionDate: normalizeDate(getVal(11)),
            lastMark: parseFloat(getVal(12)) || 10,
            status: normalizeStatus(getVal(13))
        };
        teachers.push(teacher);

        // Reconstruct Report Data
        // Check if report data exists (e.g. Wilaya at 14 or Subject at 18)
        const hasReportData = getVal(14) || getVal(18); 

        if (hasReportData) { 
            
            let legacyData: LegacyReportOptions;
            let obsStartIndex = 65; // Default for Latest New Format

            if (isLatestFormat) {
                // Read New Legacy Columns (Latest 65 cols)
                legacyData = {
                    familyStatus: getVal(31),
                    trainingInstitute: getVal(32),
                    trainingDate: normalizeDate(getVal(33)),
                    graduationDate: normalizeDate(getVal(34)),
                    schoolYear: getVal(35),
                    daira: getVal(36),
                    municipality: getVal(37),
                    classroomListening: getVal(38),
                    lighting: getVal(39),
                    heating: getVal(40),
                    ventilation: getVal(41),
                    cleanliness: getVal(42),
                    lessonPreparation: getVal(43),
                    preparationValue: getVal(44),
                    otherAids: getVal(45),
                    boardWork: getVal(46),
                    documentsAndPosters: getVal(47),
                    registers: getVal(48),
                    registersUsed: getVal(49),
                    registersMonitored: getVal(50),
                    
                    scheduledPrograms: getVal(51),
                    progression: getVal(52),
                    duties: getVal(53),

                    lessonExecution: getVal(54),
                    informationValue: getVal(55),
                    objectivesAchieved: getVal(56),
                    studentParticipation: getVal(57),
                    applications: getVal(58),
                    applicationsSuitability: getVal(59),
                    notebooksCare: getVal(60),
                    notebooksMonitored: getVal(61),
                    homeworkCorrection: getVal(62),
                    homeworkValue: getVal(63),
                    generalAppreciation: getVal(64)
                };
                obsStartIndex = 65;
            } else if (isNewFormat) {
                // Read Previous New Format (62 cols)
                legacyData = {
                    familyStatus: getVal(31),
                    trainingInstitute: getVal(32),
                    trainingDate: normalizeDate(getVal(33)),
                    graduationDate: normalizeDate(getVal(34)),
                    schoolYear: getVal(35),
                    daira: getVal(36),
                    municipality: getVal(37),
                    classroomListening: getVal(38),
                    lighting: getVal(39),
                    heating: getVal(40),
                    ventilation: getVal(41),
                    cleanliness: getVal(42),
                    lessonPreparation: getVal(43),
                    preparationValue: getVal(44),
                    otherAids: getVal(45),
                    boardWork: getVal(46),
                    documentsAndPosters: getVal(47),
                    registers: getVal(48),
                    registersUsed: getVal(49),
                    registersMonitored: getVal(50),
                    
                    // Defaults for missing fields in previous version
                    scheduledPrograms: '', 
                    progression: '',
                    duties: '',

                    lessonExecution: getVal(51),
                    informationValue: getVal(52),
                    objectivesAchieved: getVal(53),
                    studentParticipation: getVal(54),
                    applications: getVal(55),
                    applicationsSuitability: getVal(56),
                    notebooksCare: getVal(57),
                    notebooksMonitored: getVal(58),
                    homeworkCorrection: getVal(59),
                    homeworkValue: getVal(60),
                    generalAppreciation: getVal(61)
                };
                obsStartIndex = 62;
            } else {
                // Fallback for Old Sheets: Legacy Data is empty, Observations start at 29
                legacyData = { ...INITIAL_REPORT_STATE.legacyData! }; // Use default blanks
                obsStartIndex = 29;
            }

            const observations = JSON.parse(JSON.stringify(DEFAULT_OBSERVATION_TEMPLATE));
            
            let obsIndex = obsStartIndex; 
            observations.forEach((obs: ObservationItem) => {
                const scoreVal = getVal(obsIndex);
                const noteVal = getVal(obsIndex + 1);
                
                if (scoreVal === '0' || scoreVal === '1' || scoreVal === '2') {
                    obs.score = parseInt(scoreVal) as 0 | 1 | 2;
                } else {
                    obs.score = null;
                }
                
                obs.improvementNotes = noteVal || '';
                obsIndex += 2;
            });

            reportsMap[id] = {
                id: generateId(), 
                teacherId: id,
                // 29 is Report Model in New Format. In Old Format, it was Observation Score, so assume 'modern'
                reportModel: isNewFormat ? (getVal(29) === 'legacy' ? 'legacy' : 'modern') : 'modern',
                inspectorName: isNewFormat ? getVal(30) : '',
                wilaya: getVal(14),
                district: getVal(15),
                school: getVal(16),
                inspectionDate: normalizeDate(getVal(17)),
                subject: getVal(18),
                topic: getVal(19),
                duration: getVal(20),
                level: getVal(21),
                group: getVal(22),
                studentCount: parseInt(getVal(23)) || 0,
                absentCount: parseInt(getVal(24)) || 0,
                generalAssessment: getVal(25),
                finalMark: parseFloat(getVal(26)) || 0,
                markInLetters: getVal(27),
                assessmentKeywords: getVal(28),
                observations: observations,
                legacyData: legacyData
            };
        }
    }

    return { teachers, reportsMap };
};

/**
 * Generates the full CSV content with BOM for Excel Arabic support
 */
export const generateCSVContent = (
    teachers: Teacher[],
    currentReport?: ReportData,
    reportsMap?: Record<string, ReportData>
): string => {
    const rows = generateDatabaseRows(teachers, currentReport, reportsMap);
    
    // Convert to CSV
    const csv = rows.map(row => 
        row.map(cell => {
            const cellStr = String(cell || '').replace(/"/g, '""');
            // Force text mode by quoting
            return `"${cellStr}"`;
        }).join(',')
    ).join('\n');

    // Add BOM for Excel Arabic support
    return "\ufeff" + csv;
};

/**
 * Parses a CSV string into database rows
 */
export const parseCSVContent = (csvText: string) => {
    // Basic CSV parser that handles quoted strings
    const rows: string[][] = [];
    let currentRow: string[] = [];
    let currentCell = '';
    let inQuotes = false;
    
    for (let i = 0; i < csvText.length; i++) {
        const char = csvText[i];
        const nextChar = csvText[i + 1];
        
        if (char === '"') {
            if (inQuotes && nextChar === '"') {
                currentCell += '"';
                i++; // Skip escaped quote
            } else {
                inQuotes = !inQuotes;
            }
        } else if (char === ',' && !inQuotes) {
            currentRow.push(currentCell);
            currentCell = '';
        } else if ((char === '\r' || char === '\n') && !inQuotes) {
            if (char === '\r' && nextChar === '\n') i++;
            currentRow.push(currentCell);
            if (currentRow.length > 0) rows.push(currentRow);
            currentRow = [];
            currentCell = '';
        } else {
            currentCell += char;
        }
    }
    // Push last cell/row
    if (currentCell || currentRow.length > 0) {
        currentRow.push(currentCell);
        rows.push(currentRow);
    }

    return parseDatabaseRows(rows);
};


export interface Teacher {
  id: string;
  fullName: string;
  birthDate: string;
  birthPlace: string;
  degree: string;
  degreeDate?: string; 
  recruitmentDate: string; 
  currentRankDate?: string; 
  rank: string;
  echelon?: string; 
  echelonDate?: string; 
  lastInspectionDate: string;
  lastMark: number;
  status: 'stagiere' | 'contractuel' | 'titulaire'; 
}

export interface ObservationItem {
  id: string;
  category: string; 
  criteria: string; 
  indicators: string[]; 
  score: 2 | 1 | 0 | null; 
  improvementNotes: string;
}

export interface ReportData {
  id: string;
  teacherId: string;
  reportModel: 'modern' | 'legacy'; 
  inspectionDate: string;
  inspectorName?: string; 
  
  wilaya: string;
  district: string;
  school: string;

  subject: string;
  topic: string;
  duration: string;
  level: string; 
  group: string;
  studentCount: number;
  absentCount: number;
  
  observations: ObservationItem[];
  
  legacyData?: LegacyReportOptions;

  generalAssessment: string; 
  assessmentKeywords?: string; 
  finalMark: number;
  markInLetters: string;
}

export interface LegacyReportOptions {
    schoolYear: string;
    daira: string;
    municipality: string;

    familyStatus: string;
    maidenName?: string; // اللقب الأصلي (للمتزوجات)
    trainingInstitute: string; 
    trainingDate: string; 
    graduationDate: string; 
    
    classroomListening: string; 
    lighting: string;
    heating: string;
    ventilation: string;
    cleanliness: string;
    
    lessonPreparation: string; 
    preparationValue: string; 
    otherAids: string; 
    boardWork: string; 
    documentsAndPosters: string; 
    
    registers: string; 
    registersUsed: string; 
    registersMonitored: string; 
    
    // New Fields matching the document strict structure
    scheduledPrograms: string; // البرامج المقررة
    progression: string;       // التدرج
    duties: string;            // الواجبات

    lessonExecution: string; 
    informationValue: string; 
    objectivesAchieved: string; 
    studentParticipation: string; 
    applications: string; 
    applicationsSuitability: string; 

    notebooksCare: string; 
    notebooksMonitored: string; 
    homeworkCorrection: string; 
    homeworkValue: string; 
    
    generalAppreciation: string; 
}

export interface TenureLesson {
    id: string;
    order: 1 | 2 | 3;
    subject: string;
    topic: string;
    level: string;
    timeStart: string;
    timeEnd: string;
    phaseLaunch: string; 
    phaseConstruction: string; 
    phaseInvestment: string; 
}

export interface OralQuestions {
    educationScience: string;
    psychology: string;
    legislation: string;
}

export interface TenureReportData {
    id: string;
    teacherId: string;
    examDate: string;
    
    wilaya: string;
    district: string;
    school: string; 
    city: string; 

    inspectorName: string; 
    directorName: string; 
    teacherMemberName: string; 

    appointmentDecisionNumber: string; 
    appointmentDecisionDate: string;
    financialVisaNumber: string; 
    financialVisaDate: string;
    
    contestDate: string; 
    recruitmentType: string;
    university: string; // Added field for University/Institute

    lessons: TenureLesson[];

    oralQuestions: OralQuestions; // Changed from string to object
    
    pedagogyMark: number; 
    oralMark: number; 
    totalMark: number; 
    
    finalDecision: 'confirmed' | 'deferred' | 'failed'; 
    culturalValue: string; 
    pedagogicalValue: string; 
}

export enum AppView {
  DASHBOARD = 'DASHBOARD',
  EDITOR = 'EDITOR',
  LEGACY_EDITOR = 'LEGACY_EDITOR',
  PRINT = 'PRINT',
  DATABASE = 'DATABASE',
  PROMOTIONS = 'PROMOTIONS',
  TENURE_EDITOR = 'TENURE_EDITOR'
}
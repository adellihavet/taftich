import { ReportData, Teacher } from './types';
import { DEFAULT_OBSERVATION_TEMPLATE } from './modernConstants';
import { DEFAULT_LEGACY_DATA } from './legacyConstants';

// Re-export everything so other files don't break
export * from './modernConstants';
export * from './legacyConstants';
export * from './tenureConstants';

export const MOCK_TEACHERS: Teacher[] = [];

export const INITIAL_REPORT_STATE: ReportData = {
  id: '',
  teacherId: '',
  reportModel: 'modern',
  inspectionDate: new Date().toISOString().split('T')[0],
  inspectorName: '',
  wilaya: 'الأغواط',
  district: '',
  school: '',
  subject: 'اللغة العربية',
  topic: '',
  duration: '45 دقيقة',
  level: 'السنة الأولى',
  group: 'أ',
  studentCount: 25,
  absentCount: 0,
  observations: JSON.parse(JSON.stringify(DEFAULT_OBSERVATION_TEMPLATE)),
  legacyData: DEFAULT_LEGACY_DATA,
  generalAssessment: '',
  assessmentKeywords: '',
  finalMark: 0,
  markInLetters: ''
};